#include<stdlib.h>
#include<GL/glut.h>
#include<stdio.h>
static int window;
static int menu_id;
static int submenu_id;
static int value = 0;

float  x1 = 200.0, y1 = 100.0, x2 = 100.0, y2 = 200.0, x3 = 100.0, y3 = 300.0,x4 = 200.0, y4 = 400.0,x5=300,y5=300,x6=300,y6=200;
void draw_pixel(int x, int y)
{
	glColor3f(1.0, 0.0, 1.0);
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
	glFlush();
}
void edgedetect(float x1, float y1, float x2, float y2, int *le, int *re)
{
	float mx, x, temp;
	int i;
	if ((y2 - y1)<0)
	{
        temp = y1; y1 = y2; y2 = temp;
		temp = x1; x1 = x2; x2 = temp;
	}	
	if ((y2 - y1) != 0)
		mx = (x2 - x1) / (y2 - y1);
	else mx = x2 - x1;
	x = x1;
	for (i = y1; i<= y2; i++)
	{
		if (x<(float)le[i])
			le[i] = (int)x;
		if (x>(float)re[i])
			re[i] = (int)x;
		x += mx;
	}
}

void scanfill(float x1, float y1, float x2, float y2, float x3, float y3, float x4, float y4,float x5, float y5, float x6, float y6)
{
	int le[500], re[500], i, y;
	for (i = 0; i<500; i++)
	{
		le[i] = 500;
		re[i] = 0;
	}
	edgedetect(x1, y1, x2, y2, le, re);
	edgedetect(x2, y2, x3, y3, le, re);
	edgedetect(x3, y3, x4, y4, le, re);
	edgedetect(x4, y4, x5, y5, le, re);
	edgedetect(x5, y5, x6, y6, le, re);
	edgedetect(x6, y6, x1, y1, le, re);
	
    for (y = 0; y<500; y++)
	{
		if (le[y] <= re[y])
			for (i = (int)le[y]; i<(int)re[y]; i++)
				draw_pixel(i, y);
	}
}
void menu(int num){
	if (num == 0)
{
		glutDestroyWindow(window);
		exit(0);
	}
	else{
		value = num;
	}
	glutPostRedisplay();
}

void createMenu(void)
{
	submenu_id = glutCreateMenu(menu);
	glutAddMenuEntry("scanfill polygon", 2);
	menu_id = glutCreateMenu(menu);
	glutAddMenuEntry("Clear", 1);
	glutAddSubMenu("Draw", submenu_id);
	glutAddMenuEntry("Quit", 0);   
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}
void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);   
    if (value == 1)
    {
		createMenu();
		return;
	}
	else if (value == 2)
        {
		glClear(GL_COLOR_BUFFER_BIT);
		glColor3f(0.0, 0.0, 1.0);
		glBegin(GL_LINE_LOOP);
		glVertex2f(x1, y1);
		glVertex2f(x2, y2);
		glVertex2f(x3, y3);
		glVertex2f(x4, y4);
		glVertex2f(x5, y5);
		glVertex2f(x6, y6);
		glEnd();
		scanfill(x1, y1, x2, y2, x3, y3, x4, y4,x5,y5,x6,y6);
		glFlush();
	}

}
void myinit()
{
	glClearColor(1.0, 1.0, 1.0, 1.0);
	glColor3f(1.0, 0.0, 0.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, 499.0, 0.0, 499.0);
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_SINGLE);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	window = glutCreateWindow("Menu driven Programming for Scan filling ");
	createMenu();     
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glutDisplayFunc(display);  
	myinit();
	glutMainLoop();
	return EXIT_SUCCESS;
}


