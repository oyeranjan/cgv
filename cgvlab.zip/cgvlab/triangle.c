#include<stdio.h>
#include<GL/glut.h>

GLfloat theta;

void drawtria()
{
	glBegin(GL_TRIANGLES);
		glVertex2f(0.0,0.5);
		glVertex2f(0.5,-0.5);
		glVertex2f(-0.5,-0.5);
	glEnd();
}		

void display()
{
glClear(GL_COLOR_BUFFER_BIT);
glColor3f(1.0,0.0,0.0);
	glScalef(.5,.5,.5);
	glPushMatrix();
		drawtria();
	glPopMatrix();
	glPushMatrix();
		glColor3f(1.0,1.0,0.0);
		glRotatef(theta,0,0,1);
		drawtria();
	glPopMatrix();
	glPushMatrix();
		glColor3f(0.0,1.0,0.0);
		glTranslatef(-1.5,0,0);
		glRotatef(theta,0,0,1);
		drawtria();
	glPopMatrix();
glFlush();
}

void main(int a,char** v)
{
	printf("Enter the rotation angle:\n");
	scanf("%f",&theta);
	glutInit(&a,v);
	glutInitDisplayMode(GLUT_SINGLE|GLUT_RGB);
	glutInitWindowSize(500,500);
	glutInitWindowPosition(0,0);
	glutCreateWindow("Triangle Rotation");
	glClearColor(1,1,1,1);
	glutDisplayFunc(display);
	glutMainLoop();
}

